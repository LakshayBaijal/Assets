let menutoggle = document.querySelector('.menutoggle');
let tab = document.querySelector('.tab');
menutoggle.onclick = function(){
    tab.classList.toggle('active');
}
