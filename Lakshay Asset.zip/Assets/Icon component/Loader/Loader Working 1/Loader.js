setTimeout(function()
{
    time();
},3000);

function time()
{
    $('#loader').addClass("hide-loader");
}