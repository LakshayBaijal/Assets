const loader= document.querySelector('.center');
windows.addEventListener('load',()=>{
loader.classList.add('end-loader');
})